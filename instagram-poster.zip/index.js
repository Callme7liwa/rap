const { S3Client, GetObjectCommand, DeleteObjectCommand, ListObjectsV2Command } = require('@aws-sdk/client-s3');
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');

// Initialize AWS clients
const s3Client = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' });
const dynamoDBClient = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });
const docClient = DynamoDBDocumentClient.from(dynamoDBClient);

const S3_BUCKET = process.env.S3_BUCKET_NAME;
const DYNAMODB_TABLE = process.env.DYNAMODB_TABLE_NAME;
const INSTAGRAM_ACCESS_TOKEN = process.env.INSTAGRAM_ACCESS_TOKEN;
const INSTAGRAM_ACCOUNT_ID = process.env.INSTAGRAM_ACCOUNT_ID;

/**
 * Main Lambda handler
 */
exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  try {
    const triggerTime = event.trigger_time || 'unknown';
    console.log(`Triggered at: ${triggerTime}`);

    // 1. Récupérer une image aléatoire du S3 bucket
    const imageKey = await getRandomImageFromS3();
    
    if (!imageKey) {
      console.log('No images available in S3 bucket');
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'No images to post' })
      };
    }

    console.log(`Selected image: ${imageKey}`);

    // 2. Télécharger l'image depuis S3
    const imageBuffer = await downloadImageFromS3(imageKey);
    
    // 3. Uploader sur Instagram
    const instagramPostId = await uploadToInstagram(imageBuffer, imageKey);
    
    console.log(`Posted to Instagram: ${instagramPostId}`);

    // 4. Enregistrer dans DynamoDB
    await saveToDatabase(imageKey, instagramPostId, triggerTime);

    // 5. Supprimer l'image du S3
    await deleteImageFromS3(imageKey);
    
    console.log(`Deleted image from S3: ${imageKey}`);

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Successfully posted to Instagram',
        imageKey,
        instagramPostId,
        triggerTime
      })
    };

  } catch (error) {
    console.error('Error:', error);
    
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: 'Error posting to Instagram',
        error: error.message
      })
    };
  }
};

/**
 * Récupérer une image aléatoire du S3 bucket
 */
async function getRandomImageFromS3() {
  const listCommand = new ListObjectsV2Command({
    Bucket: S3_BUCKET,
    MaxKeys: 100
  });

  const response = await s3Client.send(listCommand);
  
  if (!response.Contents || response.Contents.length === 0) {
    return null;
  }

  // Filtrer uniquement les images
  const images = response.Contents.filter(obj => 
    obj.Key.match(/\.(jpg|jpeg|png)$/i)
  );

  if (images.length === 0) {
    return null;
  }

  // Sélectionner une image aléatoire
  const randomIndex = Math.floor(Math.random() * images.length);
  return images[randomIndex].Key;
}

/**
 * Télécharger l'image depuis S3
 */
async function downloadImageFromS3(key) {
  const command = new GetObjectCommand({
    Bucket: S3_BUCKET,
    Key: key
  });

  const response = await s3Client.send(command);
  
  // Convertir le stream en buffer
  const chunks = [];
  for await (const chunk of response.Body) {
    chunks.push(chunk);
  }
  
  return Buffer.concat(chunks);
}

/**
 * Uploader l'image sur Instagram via Graph API
 */
async function uploadToInstagram(imageBuffer, imageKey) {
  // Step 1: Créer un container media
  // Note: Instagram nécessite une URL publique. 
  // Alternative: Uploader d'abord sur un CDN temporaire ou utiliser un presigned URL
  
  // Pour cet exemple, on suppose que l'image est accessible via une URL
  // Vous devrez adapter selon votre architecture
  
  const imageUrl = await getPublicImageUrl(imageBuffer, imageKey);
  
  // Créer le container
  const containerResponse = await axios.post(
    `https://graph.facebook.com/v18.0/${INSTAGRAM_ACCOUNT_ID}/media`,
    {
      image_url: imageUrl,
      caption: generateCaption(imageKey),
      access_token: INSTAGRAM_ACCESS_TOKEN
    }
  );

  const creationId = containerResponse.data.id;
  console.log(`Media container created: ${creationId}`);

  // Step 2: Publier le container
  const publishResponse = await axios.post(
    `https://graph.facebook.com/v18.0/${INSTAGRAM_ACCOUNT_ID}/media_publish`,
    {
      creation_id: creationId,
      access_token: INSTAGRAM_ACCESS_TOKEN
    }
  );

  return publishResponse.data.id;
}

/**
 * Obtenir une URL publique pour l'image
 * TODO: Implémenter selon votre architecture (CloudFront, presigned URL, etc.)
 */
async function getPublicImageUrl(imageBuffer, imageKey) {
  // Option 1: Utiliser un presigned URL S3 temporaire
  // Option 2: Uploader sur CloudFront/CDN
  // Option 3: Utiliser un service tiers (Cloudinary, etc.)
  
  // Exemple avec presigned URL:
  const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
  const { GetObjectCommand } = require('@aws-sdk/client-s3');
  
  const command = new GetObjectCommand({
    Bucket: S3_BUCKET,
    Key: imageKey
  });
  
  const signedUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });
  return signedUrl;
}

/**
 * Générer une caption pour le post Instagram
 */
function generateCaption(imageKey) {
  const hashtags = [
    '#lyrics',
    '#music',
    '#hiphop',
    '#rap',
    '#quotes',
    '#musicquotes',
    '#lyricscape',
    '#dailylyrics'
  ];

  return `🎵 Daily Lyrics\n\n${hashtags.join(' ')}`;
}

/**
 * Enregistrer dans DynamoDB
 */
async function saveToDatabase(imageKey, instagramPostId, triggerTime) {
  const timestamp = new Date().toISOString();
  const ttl = Math.floor(Date.now() / 1000) + (90 * 24 * 60 * 60); // 90 jours

  const command = new PutCommand({
    TableName: DYNAMODB_TABLE,
    Item: {
      image_id: uuidv4(),
      image_key: imageKey,
      instagram_post_id: instagramPostId,
      uploaded_at: timestamp,
      trigger_time: triggerTime,
      status: 'uploaded',
      ttl: ttl
    }
  });

  await docClient.send(command);
}

/**
 * Supprimer l'image du S3
 */
async function deleteImageFromS3(key) {
  const command = new DeleteObjectCommand({
    Bucket: S3_BUCKET,
    Key: key
  });

  await s3Client.send(command);
}
